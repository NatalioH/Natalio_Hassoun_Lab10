# Lab 10 source project

See the [submission README](../README.md) for results, submission files and Jenkins setup.

This directory contains the application, deployment script, tests, requirements,
Jenkinsfile and automated Windows/Linux Jenkins validation workflow.
